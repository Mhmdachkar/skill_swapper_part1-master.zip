package com.example.skill_swaper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
