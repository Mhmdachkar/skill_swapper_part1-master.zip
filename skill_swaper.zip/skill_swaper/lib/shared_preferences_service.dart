import 'package:shared_preferences/shared_preferences.dart';

class SharedPreferencesService {
  static Future<void> saveUserData({
    required String email,
    required String password,
    required String name,
    required String birthday,
    required String phoneNumber,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('email', email);
    await prefs.setString('password', password);
    await prefs.setString('name', name);
    await prefs.setString('birthday', birthday);
    await prefs.setString('phoneNumber', phoneNumber);
  }

  static Future<Map<String, String?>> getUserData() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'email': prefs.getString('email'),
      'password': prefs.getString('password'),
      'name': prefs.getString('name'),
      'birthday': prefs.getString('birthday'),
      'phoneNumber': prefs.getString('phoneNumber'),
    };
  }

  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey('email') && prefs.containsKey('password');
  }
}
