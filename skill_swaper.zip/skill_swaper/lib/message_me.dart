import 'package:flutter/material.dart';
import 'main.dart';

class MessageMePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightGreen[600],
      appBar: CustomAppBar(title: 'Chatting'),
    );
  }
}
